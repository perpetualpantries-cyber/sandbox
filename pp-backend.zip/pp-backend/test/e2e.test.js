import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../src/app.js';
import { migrate } from '../src/migrate.js';
import { pool } from '../src/lib/db.js';

let server, base;
const api = async (method, path, { body, headers } = {}) => {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(headers || {}) }, body: body ? JSON.stringify(body) : undefined });
  let json = null; try { json = await r.json(); } catch {}
  return { status: r.status, json, headers: r.headers };
};

before(async () => {
  await migrate();
  await pool.query('TRUNCATE orgs, pp_staff, idempotency_keys RESTART IDENTITY CASCADE');
  server = createApp().listen(0);
  base = 'http://127.0.0.1:' + server.address().port;
});
after(async () => { server.close(); await pool.end(); });

const S = {};   // shared state across tests, in order

test('bootstrap owner, add sales manager', async () => {
  const r = await api('POST', '/api/pp/staff/bootstrap', { body: { name: 'Josh', email: 'josh@pp.example', password: 'correct-horse-battery' } });
  assert.equal(r.status, 201); S.owner = r.json.token;
  const again = await api('POST', '/api/pp/staff/bootstrap', { body: { name: 'X', email: 'x@pp.example', password: 'password123' } });
  assert.equal(again.status, 409);
  const sm = await api('POST', '/api/pp/staff', { headers: { Authorization: 'Bearer ' + S.owner }, body: { name: 'Sam', email: 'sam@pp.example', password: 'password123', role: 'Sales Manager' } });
  assert.equal(sm.status, 201);
  const login = await api('POST', '/api/pp/staff/login', { body: { email: 'sam@pp.example', password: 'password123' } });
  assert.equal(login.status, 200); S.sales = login.json.token;
  const bad = await api('POST', '/api/pp/staff/login', { body: { email: 'sam@pp.example', password: 'nope' } });
  assert.equal(bad.status, 401);
});

test('Canopy creates a client → org + one-time org-level link code (no raw key handed out); Sales Manager cannot rotate keys', async () => {
  const r = await api('POST', '/api/pp/clients', { headers: { Authorization: 'Bearer ' + S.sales }, body: { name: 'Harbour Cafés', sector: 'Cafés' } });
  assert.equal(r.status, 201); assert.match(r.json.linkCode.code, /^[A-HJ-NP-Z2-9]{8}$/);
  S.orgId = r.json.client.id; S.orgLinkCode = r.json.linkCode.code;
  const rot = await api('POST', `/api/pp/clients/${S.orgId}/rotate-key`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(rot.status, 403);
});

test('PP Command claims the org code once and receives the org key; a second claim fails', async () => {
  const bad = await api('POST', '/api/org/link/claim', { body: { code: 'ZZZZZZZZ' } });
  assert.equal(bad.status, 404);
  const claim = await api('POST', '/api/org/link/claim', { body: { code: S.orgLinkCode.toLowerCase() } });
  assert.equal(claim.status, 200); assert.equal(claim.json.org_name, 'Harbour Cafés'); assert.match(claim.json.api_key, /^ppo_/);
  S.orgKey = claim.json.api_key;
  const again = await api('POST', '/api/org/link/claim', { body: { code: S.orgLinkCode } });
  assert.equal(again.status, 409); assert.equal(again.json.error, 'code already used');
  // Once claimed, the org-level code can't be regenerated (the link is permanent, no unlink).
  const regen = await api('POST', `/api/pp/clients/${S.orgId}/link-code`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(regen.status, 409);
});

test('Command authenticates with the org key and issues a link code', async () => {
  const me = await api('GET', '/api/org', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(me.status, 200); assert.equal(me.json.name, 'Harbour Cafés');
  const badKey = await api('GET', '/api/org', { headers: { 'X-Org-Key': 'ppo_nope' } });
  assert.equal(badKey.status, 401);
  const c = await api('POST', '/api/org/link-codes', { headers: { 'X-Org-Key': S.orgKey }, body: { hint: 'Pier' } });
  assert.equal(c.status, 201); assert.match(c.json.code, /^[A-HJ-NP-Z2-9]{8}$/); S.code = c.json.code;
  const c2 = await api('POST', '/api/org/link-codes', { headers: { 'X-Org-Key': S.orgKey }, body: { hint: 'Wharf' } });
  S.code2 = c2.json.code;
});

test('PP redeems the code (once), gets a site token; second venue links via legacy /auth/token', async () => {
  const r = await api('POST', '/api/link/redeem', { body: { code: S.code.toLowerCase(), venue: { venue_id: 'venue_8841', cafe_name: 'Pier Café', suburb: 'Collingwood', state: 'VIC' } } });
  assert.equal(r.status, 200); assert.ok(r.json.token); assert.equal(r.json.org_name, 'Harbour Cafés');
  assert.deepEqual(Object.keys(r.json.venue).sort(), ['id', 'name']);   // never overwrites cafeDetails
  S.siteTok = r.json.token; S.siteId = r.json.site_id;
  const twice = await api('POST', '/api/link/redeem', { body: { code: S.code, venue: { venue_id: 'venue_x', cafe_name: 'X' } } });
  assert.equal(twice.status, 409); assert.equal(twice.json.error, 'code already used');
  const dupVenue = await api('POST', '/api/link/redeem', { body: { code: S.code2, venue: { venue_id: 'venue_8841', cafe_name: 'Dup' } } });
  assert.equal(dupVenue.status, 409); assert.equal(dupVenue.json.error, 'venue already linked');
  const legacy = await api('POST', '/auth/token', { body: { apiKey: S.code2, venue: { venue_id: 'venue_2290', cafe_name: 'Wharf Café' } } });
  assert.equal(legacy.status, 200); S.siteTok2 = legacy.json.token; S.siteId2 = legacy.json.site_id;
  const unknown = await api('POST', '/api/link/redeem', { body: { code: 'ZZZZZZZZ', venue: { venue_id: 'v', cafe_name: 'v' } } });
  assert.equal(unknown.status, 404);
});

test('snapshot: accepted, projected to Command; unknown keys rejected; opt-out clears payroll', async () => {
  const snap = { venue_id: 'venue_8841', cafe_name: 'Pier Café', timestamp: new Date().toISOString(), revenue_week: 18420, gp_pct: 64, labour_pct: 29, covers_week: 1240,
    stock_out: 1, stock_low: 3, stock_out_items: ['Oat Milk'], stock_low_items: ['Espresso Blend'], stock_value: 6120.5, open_orders: 2,
    loyalty: { total_members: 84, active_members: 31, avg_points: 210, redemptions: 12 },
    menu_items: [{ name: 'Flat White', sellingPrice: 5.5, category: 'Coffee' }, { name: 'Smashed Avo', sellingPrice: 22, category: 'Food' }],
    shared_payroll: [{ name: 'Sarah Chen', role: 'Barista', hourly_rate_cents: 2585, hours_this_period: 24 }] };
  const r = await api('POST', '/api/venue/snapshot', { headers: { Authorization: 'Bearer ' + S.siteTok }, body: snap });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const leak = await api('POST', '/api/venue/snapshot', { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { ...snap, oc_inventory: [{ x: 1 }] } });
  assert.equal(leak.status, 400); assert.deepEqual(leak.json.rejected_keys, ['oc_inventory']);
  const wrongVenue = await api('POST', '/api/venue/snapshot', { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { ...snap, venue_id: 'venue_2290' } });
  assert.equal(wrongVenue.status, 400);
  await api('POST', '/api/venue/snapshot', { headers: { Authorization: 'Bearer ' + S.siteTok2 }, body: { revenue_week: 14980, gp_pct: 61, labour_pct: 33, stock_out: 0, stock_low: 1, open_orders: 1 } });

  const sites = await api('GET', '/api/org/sites', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(sites.status, 200); assert.equal(sites.json.sites.length, 2);
  const pier = sites.json.sites.find(s => s.venue_id === 'venue_8841');
  assert.equal(pier.snapshot.revenue_week, 18420); assert.deepEqual(pier.snapshot.stock_out_items, ['Oat Milk']);
  assert.deepEqual(Object.keys(pier.ocData), ['oc_menu_data']);                 // the boundary
  assert.equal(pier.ocData.oc_menu_data[0].sellingPrice, 5.5);
  assert.equal(pier.sharedPayroll.length, 1);
  const ov = await api('GET', '/api/org/overview', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(ov.json.totals.revenue_week, 33400); assert.equal(ov.json.totals.avg_gp_pct, 63);   // revenue-weighted
  assert.equal(ov.json.totals.open_orders, 3);

  // opt out of payroll sharing → cleared
  await api('POST', '/api/venue/snapshot', { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { revenue_week: 18420, gp_pct: 64, labour_pct: 29 } });
  const after = await api('GET', '/api/org/sites', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(after.json.sites.find(s => s.venue_id === 'venue_8841').sharedPayroll.length, 0);
  const labour = await api('GET', '/api/org/labour', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(labour.json.sites_sharing, 0);
});

test('Ronin → Gavin: keyword gate forces approval; café approves on its own screen; Gavin acks; org sees reply', async () => {
  // Ronin says no approval needed, but "stock" in the intent forces it.
  const m = await api('POST', '/api/org/messages', { headers: { 'X-Org-Key': S.orgKey, 'Idempotency-Key': 'msg-1' }, body: { site_id: S.siteId, intent: 'check_stock_levels', note: 'Pier: check oat milk par before the promo', requires_manager_approval: false } });
  assert.equal(m.status, 201); assert.equal(m.json.message.status, 'awaiting_approval'); assert.equal(m.json.message.requires_manager_approval, true);
  const replay = await api('POST', '/api/org/messages', { headers: { 'X-Org-Key': S.orgKey, 'Idempotency-Key': 'msg-1' }, body: { site_id: S.siteId, intent: 'check_stock_levels', note: 'dup' } });
  assert.equal(replay.headers.get('idempotent-replay'), 'true'); assert.equal(replay.json.message.id, m.json.message.id);
  const id = m.json.message.id;

  // Read-only request goes straight to 'sent'
  const ro = await api('POST', '/api/org/messages', { headers: { 'X-Org-Key': S.orgKey }, body: { site_id: S.siteId, intent: 'weekly_summary', note: 'how did the week go', requires_manager_approval: false } });
  assert.equal(ro.json.message.status, 'sent');

  // Café inbox shows both; only the sent one is actionable
  const inbox = await api('GET', '/api/venue/inbox', { headers: { Authorization: 'Bearer ' + S.siteTok } });
  assert.equal(inbox.json.messages.length, 2); assert.deepEqual(inbox.json.actionable, [ro.json.message.id]);

  // Org tries to approve — refused unless the site allows it; the wrong site can't approve either
  const orgApprove = await api('POST', `/api/org/messages/${id}/approve`, { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(orgApprove.status, 403);
  const wrongSite = await api('POST', `/api/org/messages/${id}/approve`, { headers: { Authorization: 'Bearer ' + S.siteTok2 } });
  assert.equal(wrongSite.status, 403);
  // Café approves
  const ok = await api('POST', `/api/venue/inbox/${id}/approve`, { headers: { Authorization: 'Bearer ' + S.siteTok } });
  assert.equal(ok.status, 200);
  // Gavin can't ack before doing it twice; acks once
  const ack = await api('POST', `/api/venue/inbox/${id}/ack`, { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { status: 'completed', note: 'Par raised to 30 L', result: { par: 30 } } });
  assert.equal(ack.status, 200);
  const ack2 = await api('POST', `/api/venue/inbox/${id}/ack`, { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { status: 'completed' } });
  assert.equal(ack2.status, 409);

  const log = await api('GET', '/api/org/messages', { headers: { 'X-Org-Key': S.orgKey } });
  const reply = log.json.messages.find(x => x.direction === 'gavin_to_ronin' && x.reply_to === id);
  assert.ok(reply); assert.equal(reply.note, 'Par raised to 30 L');
  assert.equal(log.json.messages.find(x => x.id === id).status, 'completed');
  const notif = await api('GET', '/api/org/notifications?status=unread', { headers: { 'X-Org-Key': S.orgKey } });
  assert.ok(notif.json.notifications.some(n => n.type === 'task_done'));
});

test('coordination creates two linked, gated messages', async () => {
  const c = await api('POST', '/api/org/messages/coordinate', { headers: { 'X-Org-Key': S.orgKey }, body: { site_a_id: S.siteId, site_b_id: S.siteId2, request: 'Pier to send two crates of oat milk to Wharf', requires_manager_approval: false } });
  assert.equal(c.status, 201); assert.equal(c.json.messages.length, 2);
  assert.ok(c.json.messages.every(m => m.coordination_id === c.json.coordination_id && m.status === 'awaiting_approval'));
  assert.equal(c.json.messages[0].intent, 'coordinate_with_wharf_cafe');
});

test('Canopy → Ronin ask: operator-gated; Canopy can only withdraw', async () => {
  const a = await api('POST', '/api/pp/ronin-asks', { headers: { Authorization: 'Bearer ' + S.sales }, body: { org_id: S.orgId, message: 'Can we schedule a check-in about Q4 menu changes?', canopy_ask_id: 'local-1' } });
  assert.equal(a.status, 201); assert.equal(a.json.status, 'awaiting_approval');
  const seen = await api('GET', '/api/org/canopy-requests?status=awaiting_approval', { headers: { 'X-Org-Key': S.orgKey } });
  assert.equal(seen.json.requests.length, 1);
  const resp = await api('POST', `/api/org/canopy-requests/${a.json.id}/respond`, { headers: { 'X-Org-Key': S.orgKey }, body: { status: 'answered', response_text: 'Yes — Tuesday works.' } });
  assert.equal(resp.status, 200);
  const back = await api('GET', `/api/pp/ronin-asks?org_id=${S.orgId}`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(back.json.asks[0].status, 'answered'); assert.equal(back.json.asks[0].response_text, 'Yes — Tuesday works.');
  const w = await api('POST', `/api/pp/ronin-asks/${a.json.id}/withdraw`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(w.status, 409);
});

test('boundary: Canopy products = menu items only; IT Staff refused', async () => {
  const p = await api('GET', `/api/pp/clients/${S.orgId}/products`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(p.status, 200); assert.deepEqual(Object.keys(p.json.products[0]).sort(), ['category', 'name', 'price', 'site_id', 'site_name']);
  const it = await api('POST', '/api/pp/staff', { headers: { Authorization: 'Bearer ' + S.owner }, body: { name: 'Ida', email: 'ida@pp.example', password: 'password123', role: 'IT Staff' } });
  const login = await api('POST', '/api/pp/staff/login', { body: { email: 'ida@pp.example', password: 'password123' } });
  const denied = await api('GET', '/api/pp/clients', { headers: { Authorization: 'Bearer ' + login.json.token } });
  assert.equal(denied.status, 403);
});

test('encrypted backup round-trips and is not readable via any org route', async () => {
  const data = { oc_inventory: { itm_avo: { stock: 24 } }, oc_staff: [{ name: 'Sarah', tfn: '123 456 782' }] };
  const up = await api('POST', '/api/venue/sync', { headers: { Authorization: 'Bearer ' + S.siteTok }, body: { data, pushed_at: new Date().toISOString() } });
  assert.equal(up.status, 200);
  const down = await api('GET', '/api/venue/sync', { headers: { Authorization: 'Bearer ' + S.siteTok } });
  assert.deepEqual(down.json.data, data);
  const { rows: [b] } = await pool.query('SELECT ciphertext FROM site_backups WHERE site_id=$1', [S.siteId]);
  assert.ok(!b.ciphertext.toString('utf8').includes('123 456 782'));
  const sites = await api('GET', '/api/org/sites', { headers: { 'X-Org-Key': S.orgKey } });
  assert.ok(!JSON.stringify(sites.json).includes('tfn'));
});

test('expired and revoked codes cannot be redeemed', async () => {
  const c = await api('POST', '/api/org/link-codes', { headers: { 'X-Org-Key': S.orgKey }, body: { hint: 'Old' } });
  await pool.query(`UPDATE link_codes SET expires_at = now() - interval '1 minute' WHERE id=$1`, [c.json.id]);
  const r = await api('POST', '/api/link/redeem', { body: { code: c.json.code, venue: { venue_id: 'venue_old', cafe_name: 'Old' } } });
  assert.equal(r.status, 409); assert.equal(r.json.error, 'code expired');
  const c2 = await api('POST', '/api/org/link-codes', { headers: { 'X-Org-Key': S.orgKey }, body: { hint: 'Rev' } });
  await api('DELETE', `/api/org/link-codes/${c2.json.id}`, { headers: { 'X-Org-Key': S.orgKey } });
  const r2 = await api('POST', '/api/link/redeem', { body: { code: c2.json.code, venue: { venue_id: 'venue_rev', cafe_name: 'Rev' } } });
  assert.equal(r2.status, 409); assert.equal(r2.json.error, 'code revoked');
});

test('org-level code: expires, and can be freely regenerated before it is ever claimed', async () => {
  const created = await api('POST', '/api/pp/clients', { headers: { Authorization: 'Bearer ' + S.sales }, body: { name: 'Second Site Co', sector: 'Cafés' } });
  const orgId = created.json.client.id;
  await pool.query(`UPDATE link_codes SET expires_at = now() - interval '1 minute' WHERE org_id=$1 AND kind='org'`, [orgId]);
  const staleClaim = await api('POST', '/api/org/link/claim', { body: { code: created.json.linkCode.code } });
  assert.equal(staleClaim.status, 409); assert.equal(staleClaim.json.error, 'code expired');
  // Regenerating is fine pre-claim — no unlink needed since nothing was ever linked.
  const fresh = await api('POST', `/api/pp/clients/${orgId}/link-code`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(fresh.status, 201); assert.notEqual(fresh.json.code, created.json.linkCode.code);
  const claimFresh = await api('POST', '/api/org/link/claim', { body: { code: fresh.json.code } });
  assert.equal(claimFresh.status, 200); assert.equal(claimFresh.json.org_name, 'Second Site Co');
  // And now that it's claimed, regenerating again is refused.
  const again = await api('POST', `/api/pp/clients/${orgId}/link-code`, { headers: { Authorization: 'Bearer ' + S.sales } });
  assert.equal(again.status, 409);
});
